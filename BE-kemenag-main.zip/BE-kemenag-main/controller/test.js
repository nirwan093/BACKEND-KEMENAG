const express = require('express')
const getTest = (res, req) => {
    res.send("Hello")
}
